/**
 * @program school-bus-cloud
 * @description: AbstractRequest
 * @author: mf
 * @create: 2020/10/31 15:24
 */

package com.dream.bus.param;

import java.io.Serializable;

public abstract class AbstractRequest implements Serializable {
    private static final long serialVersionUID = 171717171717171L;
}
