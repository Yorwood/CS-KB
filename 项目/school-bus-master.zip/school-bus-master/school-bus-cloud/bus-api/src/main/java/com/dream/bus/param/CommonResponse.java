/**
 * @program school-bus-cloud
 * @description: CommonResponse
 * @author: mf
 * @create: 2020/10/31 15:51
 */

package com.dream.bus.param;

import lombok.Data;

@Data
public class CommonResponse extends AbstractResponse{
}
