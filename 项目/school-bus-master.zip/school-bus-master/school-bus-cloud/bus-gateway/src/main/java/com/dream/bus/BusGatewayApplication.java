package com.dream.bus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(BusGatewayApplication.class, args);
    }

}
