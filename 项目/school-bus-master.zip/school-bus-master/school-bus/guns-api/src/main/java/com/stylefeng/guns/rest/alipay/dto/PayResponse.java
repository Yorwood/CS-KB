/**
 * @program school-bus
 * @description: PayResponse
 * @author: mf
 * @create: 2020/03/17 16:55
 */

package com.stylefeng.guns.rest.alipay.dto;

import com.stylefeng.guns.rest.common.AbstractResponse;
import lombok.Data;

@Data
public class PayResponse extends AbstractResponse {

}
