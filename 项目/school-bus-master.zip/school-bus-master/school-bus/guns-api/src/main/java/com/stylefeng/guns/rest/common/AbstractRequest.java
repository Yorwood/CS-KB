/**
 * @program school-bus
 * @description: AbstractRequest
 * @author: mf
 * @create: 2020/02/24 16:16
 */

package com.stylefeng.guns.rest.common;

import java.io.Serializable;

public abstract class AbstractRequest implements Serializable {

    private static final long serialVersionUID = 171717171717171L;

}
