/**
 * @program school-bus
 * @description: CommonResponse
 * @author: mf
 * @create: 2020/03/08 11:32
 */

package com.stylefeng.guns.rest.exception;

import com.stylefeng.guns.rest.common.AbstractResponse;
import lombok.Data;


public class CommonResponse extends AbstractResponse {
}
