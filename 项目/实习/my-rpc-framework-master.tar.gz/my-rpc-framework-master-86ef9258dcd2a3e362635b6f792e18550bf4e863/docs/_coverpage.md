# 一起写个Dubbo！

- 基于Netty
- 多种序列化算法
- 多种负载均衡策略

[GitHub](https://github.com/CN-GuoZiyang/My-RPC-Framework)
[README](#My-RPC-Framework)