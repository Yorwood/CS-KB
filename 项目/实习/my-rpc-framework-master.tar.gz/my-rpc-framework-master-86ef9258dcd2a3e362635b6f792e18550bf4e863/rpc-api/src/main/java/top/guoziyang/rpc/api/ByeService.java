package top.guoziyang.rpc.api;

/**
 * @author ziyang
 */
public interface ByeService {

    String bye(String name);

}
