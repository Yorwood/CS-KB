package top.guoziyang.rpc.api;

/**
 * 测试用api的接口
 *
 * @author ziyang
 */
public interface HelloService {

    String hello(HelloObject object);

}
